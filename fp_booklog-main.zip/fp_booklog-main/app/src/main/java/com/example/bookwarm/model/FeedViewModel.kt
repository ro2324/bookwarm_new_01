package com.example.bookwarm.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class FeedViewModel : ViewModel() {
    private val _feedReviews = MutableLiveData<List<BookMeta>>()
    val feedReviews: LiveData<List<BookMeta>> get() = _feedReviews
    private val firestore = FirebaseFirestore.getInstance()

    private val _suggestedUsers = MutableLiveData<List<UserProfile>>()
    val suggestedUsers: LiveData<List<UserProfile>> get() = _suggestedUsers

    fun loadSocialFeed(currentUserId: String) {
        firestore.collection("users").document(currentUserId)
            .get()
            .addOnSuccessListener { userDoc ->
                val following = (userDoc.get("following") as? List<*>)?.mapNotNull { it as? String } ?: listOf()

                if (_suggestedUsers.value.isNullOrEmpty()) {
                    fetchSuggestedUsers(currentUserId)
                }

                if (following.isEmpty()) {
                    _feedReviews.postValue(emptyList())
                    return@addOnSuccessListener
                }

                if (following.size > 10) {
                    // Optional: handle chunked listeners for >10 users
                    Log.w("FeedViewModel", "Following too many users for whereIn query")
                    return@addOnSuccessListener
                }
                firestore.collection("logged_books")
                    .whereIn("userId", following)
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .addSnapshotListener { snapshot, error ->
                        if (error != null || snapshot == null) {
                            _feedReviews.postValue(emptyList())
                            return@addSnapshotListener
                        }
                        val reviews = snapshot.documents.mapNotNull { doc ->
                            val likedBy = doc.get("likedBy") as? List<*>
                            val isLiked = likedBy?.contains(currentUserId) == true

                            doc.toObject(BookMeta::class.java)?.copy(
                                firestoreID = doc.id,
                                isLiked = isLiked
                            )
                        }

                        enrichReviewsWithUserInfo(reviews)
                    }
            }
    }


    fun fetchSuggestedUsers(currentUserId: String) {
        firestore.collection("users").document(currentUserId).get()
            .addOnSuccessListener { userDoc ->
                val following = (userDoc.get("following") as? List<*>)?.mapNotNull { it as? String }
                    ?: emptyList()

                firestore.collection("users")
                    .get()
                    .addOnSuccessListener { snapshot ->
                        val users = snapshot.documents
                            .filter { it.id != currentUserId && !following.contains(it.id) }
                            .mapNotNull { doc ->
                                UserProfile(
                                    userId = doc.id,
                                    name = doc.getString("name") ?: doc.getString("displayName")
                                    ?: "Anonymous",
                                    profilePicUrl = doc.getString("profilePicUrl")
                                )
                            }
                            .take(5)

                        Log.d("FeedViewModel", "Fetched ${users.size} filtered suggested users")
                        _suggestedUsers.postValue(users)
                    }
            }
    }

    private fun enrichReviewsWithUserInfo(reviews: List<BookMeta>) {
        val tasks = reviews.map { review ->
            firestore.collection("users").document(review.userId).get()
                .continueWith { task ->
                    val doc = task.result
                    val name = doc?.getString("name") ?: "Anonymous"
                    val photoUrl = doc?.getString("profilePicUrl")
                    review.copy(
                        reviewerName = name,
                        reviewerPhotoUrl = photoUrl
                    )
                }
        }

        com.google.android.gms.tasks.Tasks.whenAllSuccess<BookMeta>(tasks)
            .addOnSuccessListener { enriched ->
                _feedReviews.postValue(enriched.sortedByDescending { it.timestamp })
            }
    }

    fun clearFeed() {
        _feedReviews.postValue(emptyList())
    }
}
