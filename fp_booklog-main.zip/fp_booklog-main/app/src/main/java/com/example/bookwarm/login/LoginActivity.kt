package com.example.bookwarm.login

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.bookwarm.R
import com.example.bookwarm.home.HomeActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient

    private val TAG = "LoginActivity"

    //@TODO("Add Google Sign-In")
    private val signInLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                try {
                    val account = task.getResult(ApiException::class.java)!!
                    firebaseAuthWithGoogle(account)
                } catch (e: ApiException) {
                    Log.e(TAG, "Google sign-in failed", e)
                    showToast("Google sign-in failed: ${e.statusCode}")
                }
            } else {
                showToast("Google sign-in cancelled")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()
        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val signUpButton = findViewById<Button>(R.id.signUpButton)

        // Set up Google Sign-In options
        @Suppress("DEPRECATION") // Still needed for Firebase integration
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Email login
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            if (email.isNotEmpty() && password.isNotEmpty()) {
                signInWithEmail(email, password)
            } else {
                showToast("Please enter email and password")
            }
        }

        // Email sign-up
        signUpButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            if (email.isNotEmpty() && password.isNotEmpty()) {
                signUpWithEmail(email, password)
            } else {
                showToast("Please enter email and password")
            }
        }

        // Auto-login if user is already authenticated - Keep it false if you want to login everytime.
        val autoLogin = intent.getBooleanExtra("autoLogin", false)
        if (autoLogin && auth.currentUser != null) {
            goToMain()
        }
    }

    private fun signInWithEmail(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    user?.let { saveUserToFireStoreIfNew(it) }
                    goToMain()
                } else {
                    showToast("Login failed: ${task.exception?.message}")
                }
            }
    }

    private fun signUpWithEmail(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = task.result?.user
                    user?.let { saveUserToFireStoreIfNew(it) }
                    showToast("Sign-up successful")
                    goToMain()
                } else {
                    showToast("Sign-up failed: ${task.exception?.message}")
                }
            }
    }

    private fun firebaseAuthWithGoogle(account: GoogleSignInAccount) {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    user?.let { saveUserToFireStoreIfNew(it) }
                    showToast("Google login successful")
                    goToMain()
                }
                else {
                    showToast("Google login failed: ${task.exception?.message}")
                }
            }
    }

    private fun goToMain() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun saveUserToFireStoreIfNew(user: FirebaseUser) {
        Log.d("FirestoreDebug", "Checking if user doc exists for UID: ${user.uid}")

        val userDocRef = FirebaseFirestore.getInstance()
            .collection("users")
            .document(user.uid)

        userDocRef.get()
            .addOnSuccessListener { document ->
                if (!document.exists()) {
                    val userData = hashMapOf(
                        "displayName" to (user.displayName?: ""),
                        "email" to (user.email ?: ""),
                        "photoUrl" to (user.photoUrl?.toString() ?: ""),
                        "timestamp" to System.currentTimeMillis()
                    )
                    userDocRef.set(userData)
                        .addOnSuccessListener { Log.d("LoginActivity", "User added to Firestore") }
                        .addOnFailureListener { e -> Log.e("LoginActivity", "Failed to add user", e) }
                }
            }
            .addOnFailureListener { e ->
                Log.e("LoginActivity", "Failed to fetch user document", e)
            }
    }


}
