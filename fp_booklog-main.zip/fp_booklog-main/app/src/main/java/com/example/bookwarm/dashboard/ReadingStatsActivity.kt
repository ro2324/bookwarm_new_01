package com.example.bookwarm.dashboard

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.bookwarm.R

class ReadingStatsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reading_stats)

        supportFragmentManager.beginTransaction()
            .replace(R.id.statsFragmentContainer, ReadingStatsFragment())
            .commit()
    }
}
