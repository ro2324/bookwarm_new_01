package com.example.bookwarm.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bookwarm.R
import com.example.bookwarm.databinding.ItemFeedBinding
import com.example.bookwarm.model.BookMeta
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class FeedAdapter : ListAdapter<BookMeta, FeedAdapter.FeedViewHolder>(DIFF_CALLBACK) {
    private val likedSet = mutableSetOf<String>()


    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<BookMeta>() {
            override fun areItemsTheSame(oldItem: BookMeta, newItem: BookMeta): Boolean {
                return oldItem.firestoreID == newItem.firestoreID
            }

            override fun areContentsTheSame(oldItem: BookMeta, newItem: BookMeta): Boolean {
                return oldItem == newItem
            }
        }
    }

    inner class FeedViewHolder(val binding: ItemFeedBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(book: BookMeta) {
            binding.title.text = book.title
            binding.author.text = book.author
            binding.reviewText.text = book.review
            binding.ratingBar.rating = book.rating

            val isLiked = likedSet.contains(book.firestoreID)
            updateLikeIcon(isLiked)


            val timestamp = book.timestamp
            val formatted = getTimeAgo(timestamp)

            // Always clear first
            Glide.with(binding.root.context).clear(binding.reviewImage)

            if (!book.imageUrl.isNullOrBlank()) {
                binding.reviewImage.visibility = View.VISIBLE
                Glide.with(binding.root.context)
                    .load(book.imageUrl)
                    .placeholder(R.drawable.default_image) // optional but recommended
                    .error(R.drawable.default_image)       // fallback if image fails
                    .centerCrop()
                    .into(binding.reviewImage)
            } else {
                binding.reviewImage.visibility = View.GONE
            }


            // Share button
            binding.shareButton.setOnClickListener {
                val context = binding.root.context
                val shareIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, "${book.title} by ${book.author}\n\n${book.review}")
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(shareIntent, "Share via"))
            }

            // Like button (static icon for now)
            binding.likeButton.setImageResource(
                if (book.isLiked) R.drawable.baseline_thumb_up_filled_24
                else R.drawable.baseline_thumb_up_24
            )
            binding.likeButton.setOnClickListener {
                val context = binding.root.context
                val firestore = FirebaseFirestore.getInstance()
                val reviewRef = firestore.collection("logged_books").document(book.firestoreID)
                val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: return@setOnClickListener
                val alreadyLiked = book.likedBy?.contains(currentUserId) == true

                if (alreadyLiked) {
                    reviewRef.update("likedBy", FieldValue.arrayRemove(currentUserId))
                    book.isLiked = false
                    updateLikeIcon(false)
                    Toast.makeText(context, "Unliked", Toast.LENGTH_SHORT).show()
                } else {
                    reviewRef.update("likedBy", FieldValue.arrayUnion(currentUserId))
                    book.isLiked = true
                    updateLikeIcon(true)
                    Toast.makeText(context, "Liked", Toast.LENGTH_SHORT).show()
                }
            }

            binding.likeCount.text = book.likedBy?.size?.toString() ?: "0"
            binding.reviewerInfo.text = "Reviewed by ${book.reviewerName ?: "Anonymous"} · ${getTimeAgo(book.timestamp)}"


            // Reviewer Profile Picture
            if (!book.reviewerPhotoUrl.isNullOrBlank()) {
                binding.reviewerProfilePic.visibility = View.VISIBLE
                Glide.with(binding.root.context)
                    .load(book.reviewerPhotoUrl)
                    .placeholder(R.drawable.default_avatar) // Add a default profile image
                    .error(R.drawable.default_avatar) // Add a default profile image
                    .circleCrop()
                    .into(binding.reviewerProfilePic)
            } else {
                binding.reviewerProfilePic.visibility = View.GONE
            }

        }

        private fun updateLikeIcon(isLiked: Boolean) {
            binding.likeButton.setImageResource(
                if (isLiked) R.drawable.baseline_thumb_up_filled_24
                else R.drawable.baseline_thumb_up_24
            )
        }

        private fun getTimeAgo(timestamp: Long): String {
            val now = System.currentTimeMillis()
            val diff = now - timestamp

            val seconds = diff / 1000
            val minutes = seconds / 60
            val hours = minutes / 60
            val days = hours / 24

            return when {
                days > 0 -> "$days day${if (days > 1) "s" else ""} ago"
                hours > 0 -> "$hours hour${if (hours > 1) "s" else ""} ago"
                minutes > 0 -> "$minutes minute${if (minutes > 1) "s" else ""} ago"
                else -> "just now"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeedViewHolder {
        val binding = ItemFeedBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return FeedViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FeedViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}

