package com.example.bookwarm.adapter

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bookwarm.R
import com.example.bookwarm.activity.FullImageActivity
import com.example.bookwarm.review.LogBookActivity
import com.example.bookwarm.model.BookMeta

class BookMetaAdapter : RecyclerView.Adapter<BookMetaAdapter.BookMetaViewHolder>() {

    private val books = mutableListOf<BookMeta>()

    @SuppressLint("NotifyDataSetChanged")
    fun submitList(newList: List<BookMeta>) {
        books.clear()
        books.addAll(newList)
        notifyDataSetChanged()
    }

    inner class BookMetaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleText: TextView = itemView.findViewById(R.id.loggedBookTitle)
        val authorText: TextView = itemView.findViewById(R.id.loggedBookAuthor)
        val reviewText: TextView = itemView.findViewById(R.id.loggedBookReview)
        val ratingBar: RatingBar = itemView.findViewById(R.id.loggedBookRating)
        val bookImage: ImageView = itemView.findViewById(R.id.loggedBookImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookMetaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_logged_book, parent, false)
        return BookMetaViewHolder(view)
    }

    override fun onBindViewHolder(holder: BookMetaViewHolder, position: Int) {
        val book = books[position]
        holder.titleText.text = book.title
        holder.authorText.text = book.author
        holder.reviewText.text = book.review
        holder.ratingBar.rating = book.rating

        // Handle image visibility
        if (!book.imageUrl.isNullOrEmpty()) {
            holder.bookImage.visibility = View.VISIBLE
            Glide.with(holder.itemView.context)
                .load(book.imageUrl)
                .placeholder(android.R.drawable.ic_menu_report_image)
                .into(holder.bookImage)
        } else {
            holder.bookImage.visibility = View.GONE
        }

        holder.bookImage.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, FullImageActivity::class.java)
            intent.putExtra("imageUrl", book.imageUrl)
            context.startActivity(intent)
        }
        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent =
                Intent(context, LogBookActivity::class.java).apply {
                    putExtra("bookMeta", book)
                    putExtra("isEdit", true)
                }
            context.startActivity(intent)
        }

    }


    override fun getItemCount(): Int = books.size
}
