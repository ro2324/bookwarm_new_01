package com.example.bookwarm.booksearch

import android.os.Bundle
import android.util.Log
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.bookwarm.R
import com.example.bookwarm.adapter.BookAdapter
import com.example.bookwarm.model.Book


class BookSearchActivity : AppCompatActivity() {

    private lateinit var searchEditText: EditText
    private lateinit var searchButton: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: BookAdapter

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_search)
        searchEditText = findViewById(R.id.searchEditText)
        searchButton = findViewById(R.id.searchButton)
        recyclerView = findViewById(R.id.resultsRecyclerView)
        adapter = BookAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        Toast.makeText(
            this,
            "Please enter at least 3 characters. For example, try 'Harry Potter'",
            Toast.LENGTH_LONG
        ).show()
        searchButton.setOnClickListener {
            val query = searchEditText.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a search query", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Log.d("BookSearch", "Search clicked with: $query")
            Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            if (query.isNotEmpty()) {
                searchBooks(query)
            }
        }

        searchEditText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchButton.performClick()
                true
            } else {
                false
            }
        }
    }

    private fun searchBooks(query: String) {
        val url = "https://www.googleapis.com/books/v1/volumes?q=${query.replace(" ", "+")}"
        val requestQueue = Volley.newRequestQueue(this)
        val jsonObjectRequest = JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                val results = mutableListOf<Book>()
                val items = response.optJSONArray("items")
                if (items != null) {
                    for (i in 0 until items.length()) {
                        val item = items.getJSONObject(i)
                        val volumeInfo = item.getJSONObject("volumeInfo")
                        Log.d("BookSearch", "volumeInfo JSON: $volumeInfo")
                        val title = volumeInfo.optString("title", "N/A")
                        val authorsArray = volumeInfo.optJSONArray("authors")
                        val authors = if (authorsArray != null) {
                            (0 until authorsArray.length()).joinToString(", ") { j ->
                                authorsArray.getString(j)
                            }
                        } else "Unknown Author"
                        val imageLinks = volumeInfo.optJSONObject("imageLinks")
                        val thumbnail = imageLinks?.optString("thumbnail") ?: ""

                        val category = if (volumeInfo.has("categories")) {
                            val categoryArray = volumeInfo.getJSONArray("categories")
                            if (categoryArray.length() > 0) categoryArray.getString(0) else "Other"
                        } else {
                            "Other"
                        }
                        results.add(Book(title, authors, thumbnail, category))
                    }
                }

                Log.d("BookSearch", "Books found: ${results.size}")
                for (book in results) {
                    Log.d("BookSearch", "Book: ${book.title} by ${book.authors}")
                }
                adapter.submitList(results)
            },
            { error ->
                Toast.makeText(this, "Failed to fetch books", Toast.LENGTH_SHORT).show()
                Log.e("BookSearch", "Error fetching books", error)
            }
        )
        requestQueue.add(jsonObjectRequest)
    }
}