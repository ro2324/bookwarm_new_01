package com.example.bookwarm.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bookwarm.R
import com.example.bookwarm.review.LogBookActivity
import com.example.bookwarm.model.Book

class BookAdapter : RecyclerView.Adapter<BookAdapter.BookViewHolder>() {

    private val books = mutableListOf<Book>()

    fun submitList(newList: List<Book>) {
        books.clear()
        books.addAll(newList)
        notifyDataSetChanged()
    }

    class BookViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val titleText: TextView = view.findViewById(R.id.bookTitle)
        val authorText: TextView = view.findViewById(R.id.bookAuthor)
        val thumbnailImage: ImageView = view.findViewById(R.id.bookThumbnail)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_book_result, parent, false)
        return BookViewHolder(view)
    }

    override fun getItemCount(): Int = books.size

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        val book = books[position]
        holder.titleText.text = book.title
        holder.authorText.text = book.authors
        Glide.with(holder.thumbnailImage.context)
            .load(book.thumbnail)
            .into(holder.thumbnailImage)

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, LogBookActivity::class.java).apply {
                putExtra("title", book.title)
                putExtra("author", book.authors)
                putExtra("thumbnail", book.thumbnail)
                putExtra("genre", book.genre)
            }
            context.startActivity(intent)
        }
    }
}
