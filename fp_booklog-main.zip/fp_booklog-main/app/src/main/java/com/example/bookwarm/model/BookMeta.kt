package com.example.bookwarm.model

import java.io.Serializable

data class BookMeta(
    var firestoreID: String = "",
    var title: String = "",
    var author: String = "",
    var review: String = "",
    var rating: Float = 0f,
    var imageUUID: String = "",
    var imageUrl: String? = null,
    var userId: String = "",
    var timestamp: Long = 0L,
    var isLiked: Boolean = false,
    var likedBy: List<String> = listOf(),
    var reviewerName: String? = null,
    var reviewerPhotoUrl: String? = null,
    var genre: String = "Other"

) : Serializable
