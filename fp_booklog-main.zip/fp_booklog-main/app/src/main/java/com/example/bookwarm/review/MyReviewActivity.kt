package com.example.bookwarm.review

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bookwarm.R
import com.example.bookwarm.adapter.BookMetaAdapter
import com.example.bookwarm.booksearch.BookSearchActivity
import com.example.bookwarm.home.HomeActivity
import com.example.bookwarm.model.MyReviewViewModel
import com.google.firebase.auth.FirebaseAuth

class MyReviewActivity : AppCompatActivity() {

    private lateinit var adapter: BookMetaAdapter
    private val viewModel: MyReviewViewModel by viewModels()
    private val userId = FirebaseAuth.getInstance().currentUser?.uid ?: "anonymous"
    private var dialogShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_feed)

        val recyclerView = findViewById<RecyclerView>(R.id.bookRecyclerView)
        adapter = BookMetaAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        viewModel.userBooks.observe(this) { books ->
            Log.d("MyReviewActivity", "Books received: ${books.size}")

            adapter.submitList(books)
            if (books.isEmpty() && !dialogShown) {
                dialogShown = true
                showEmptyReviewDialog()
            }
        }
        viewModel.fetchUserBooks(userId)
    }

    private fun showEmptyReviewDialog() {
        if (isFinishing || isDestroyed) return

        AlertDialog.Builder(this)
            .setTitle("No Reviews Yet")
            .setMessage("Ah! You don't have any book reviews.\nWould you like to add one?")
            .setPositiveButton("Yes") { _, _ ->
                startActivity(Intent(this, BookSearchActivity::class.java))
                finish()
            }
            .setNegativeButton("No") { _, _ ->
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }
            .setCancelable(false)
            .show()
    }
}
