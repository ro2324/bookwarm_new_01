package com.example.bookwarm.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.bookwarm.databinding.FragmentReadingStatsBinding
import com.example.bookwarm.ui.stats.ReadingStatsViewModel
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.google.firebase.auth.FirebaseAuth

class ReadingStatsFragment : Fragment() {

    private var _binding: FragmentReadingStatsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ReadingStatsViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentReadingStatsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val userId = FirebaseAuth.getInstance().currentUser?.uid
        if (userId != null) {
            viewModel.loadUserStats(userId)
        }


        viewModel.totalBooks.observe(viewLifecycleOwner) {
            binding.totalBooksText.text = "Total Books Read: $it"
            showEmptyMessageIfNeeded()
        }

        viewModel.averageRating.observe(viewLifecycleOwner) {
            binding.averageRatingText.text = "Average Rating: $it"
        }

        viewModel.monthlyReadingData.observe(viewLifecycleOwner) {
            setBarChart(it)
        }

        viewModel.genreDistribution.observe(viewLifecycleOwner) {
            setPieChart(it)
        }
    }

    private fun setBarChart(data: Map<String, Int>) {
        val entries = data.entries.mapIndexed { index, (month, count) ->
            BarEntry(index.toFloat(), count.toFloat())
        }

        val dataSet = BarDataSet(entries, "Books per Month")
        val barData = BarData(dataSet)

        binding.monthlyBooksChart.apply {
            this.data = barData
            description.isEnabled = false
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            axisRight.isEnabled = false
            axisLeft.axisMinimum = 0f
            xAxis.granularity = 1f
            invalidate()
        }
    }

    private fun setPieChart(data: Map<String, Float>) {
        val entries = data.entries.map { PieEntry(it.value, it.key) }
        val dataSet = PieDataSet(entries, "Genre Distribution")
        val pieData = PieData(dataSet)

        binding.genrePieChart.apply {
            this.data = pieData
            description.isEnabled = false
            isRotationEnabled = true
            invalidate()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun showEmptyMessageIfNeeded() {
        val isEmpty = viewModel.totalBooks.value == 0 || viewModel.totalBooks.value == null
        if (isEmpty) {
            binding.totalBooksText.text = "There is no data available"
            binding.monthlyBooksChart.visibility = View.GONE
            binding.genrePieChart.visibility = View.GONE
            binding.averageRatingText.visibility = View.GONE
        }
    }

}
