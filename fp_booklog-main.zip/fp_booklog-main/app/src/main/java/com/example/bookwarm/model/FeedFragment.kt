package com.example.bookwarm.model

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bookwarm.adapter.FeedAdapter
import com.example.bookwarm.adapter.SuggestionsAdapter
import com.example.bookwarm.databinding.FragmentFeedBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class FeedFragment : Fragment() {
    private lateinit var binding: FragmentFeedBinding
    private val viewModel: FeedViewModel by viewModels()
    private lateinit var adapter: FeedAdapter
    private var suggestionsClosed = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFeedBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = FeedAdapter()
        binding.feedRecyclerView.adapter = adapter
        binding.feedRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        val suggestionsAdapter = SuggestionsAdapter { userId ->
            followUser(userId)
        }
        binding.suggestionsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.suggestionsRecyclerView.adapter = suggestionsAdapter

        // Get current user ID
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
        currentUserId?.let { viewModel.loadSocialFeed(it) }

        viewModel.suggestedUsers.observe(viewLifecycleOwner) { suggestions ->
            Log.d("FeedFragment", "Suggestions observed: ${suggestions.size}")

            if (suggestions.isNotEmpty()) {
                binding.suggestionsLayout.visibility = View.VISIBLE
                suggestionsAdapter.submitList(suggestions)
                binding.emptyFeedText.visibility = View.GONE
            } else {
                binding.suggestionsLayout.visibility = View.GONE
                if (adapter.currentList.isEmpty()) {
                    binding.emptyFeedText.visibility = View.VISIBLE
                }
            }
        }


        // Observe the feed
        viewModel.feedReviews.observe(viewLifecycleOwner) { reviews ->
            Log.d("FeedFragment", "Feed updated with ${reviews.size} items")

            adapter.submitList(reviews)

            val suggestionsExist = viewModel.suggestedUsers.value?.isNotEmpty() == true
            val showEmptyMessage = reviews.isNullOrEmpty() && !suggestionsExist

            binding.emptyFeedText.visibility = if (showEmptyMessage) View.VISIBLE else View.GONE
            binding.feedRecyclerView.visibility =
                if (reviews.isNullOrEmpty()) View.GONE else View.VISIBLE
        }

        binding.closeSuggestionsButton.setOnClickListener {
            suggestionsClosed = true
            binding.suggestionsLayout.visibility = View.GONE

            val currentUserId = FirebaseAuth.getInstance().currentUser?.uid
            currentUserId?.let {
                Log.d("FeedFragment", "Reloading feed after suggestions closed")
                viewModel.clearFeed()
                viewModel.loadSocialFeed(it)
            }

            if (adapter.currentList.isEmpty()) {
                binding.emptyFeedText.visibility = View.VISIBLE
            }
        }


    }

    private fun followUser(targetUserId: String) {
        val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        FirebaseFirestore.getInstance().collection("users").document(currentUserId)
            .update("following", FieldValue.arrayUnion(targetUserId))
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Followed successfully!", Toast.LENGTH_SHORT).show()
                viewModel.clearFeed()
                viewModel.loadSocialFeed(currentUserId)
                viewModel.fetchSuggestedUsers(currentUserId)
            }
    }
}