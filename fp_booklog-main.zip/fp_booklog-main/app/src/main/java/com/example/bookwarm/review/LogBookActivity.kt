package com.example.bookwarm.review

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.bumptech.glide.Glide
import com.example.bookwarm.R
import com.example.bookwarm.activity.FullImageActivity
import com.example.bookwarm.db.BookDBHelper
import com.example.bookwarm.db.BookStorage
import com.example.bookwarm.model.BookMeta
import com.google.firebase.auth.FirebaseAuth
import java.io.File
import android.Manifest

class LogBookActivity : AppCompatActivity() {

    private lateinit var titleEditText: EditText
    private lateinit var authorEditText: EditText
    private lateinit var reviewEditText: EditText
    private lateinit var ratingBar: RatingBar
    private lateinit var bookImageView: ImageView
    private lateinit var uploadButton: Button
    private lateinit var submitButton: Button
    private lateinit var deleteImageButton: Button
    private lateinit var imageUri: Uri


    private val bookStorage = BookStorage()
    private val dbHelper = BookDBHelper()

    private var selectedImageUri: Uri? = null
    private val userId = FirebaseAuth.getInstance().currentUser?.uid ?: "anonymous"

    private var isEdit = false
    private var editingBook: BookMeta? = null

    private val imagePickerLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            selectedImageUri = uri
            uri?.let {
                Glide.with(this).load(it).into(bookImageView)
                deleteImageButton.visibility = View.VISIBLE
            }
        }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) {
                Glide.with(this).load(imageUri).into(bookImageView)
                selectedImageUri = imageUri
            }
        }

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                Glide.with(this).load(it).into(bookImageView)
                selectedImageUri = it
            }
        }

    private fun showImagePickerDialog() {
        val options = arrayOf("Take Photo", "Choose from Gallery")
        AlertDialog.Builder(this)
            .setTitle("Select Image")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> checkCameraPermission()
                    1 -> galleryLauncher.launch("image/*")
                }
            }
            .show()
    }

    private fun checkCameraPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                launchCamera()
            }
            shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) -> {
                showRationaleDialog()
            }
            else -> {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun showRationaleDialog() {
        AlertDialog.Builder(this)
            .setTitle("Camera Permission Needed")
            .setMessage("This app needs the Camera permission to take photos of books")
            .setPositiveButton("OK") { _, _ ->
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launchCamera() {
        try {
            val photoFile = createImageFile()
            imageUri = FileProvider.getUriForFile(
                this,
                "${packageName}.provider",
                photoFile
            )
            cameraLauncher.launch(imageUri)
        } catch (e: Exception) {
            Toast.makeText(this, "Error creating file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createImageFile(): File {
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${System.currentTimeMillis()}_",
            ".jpg",
            storageDir
        ).apply {
            // Create empty file immediately
            createNewFile()
        }
    }


    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            launchCamera()
        } else {
            Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
        }
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_book)

        // View bindings
        titleEditText = findViewById(R.id.titleEditText)
        authorEditText = findViewById(R.id.authorEditText)
        reviewEditText = findViewById(R.id.reviewEditText)
        ratingBar = findViewById(R.id.ratingBar)
        bookImageView = findViewById(R.id.bookImageView)
        uploadButton = findViewById(R.id.uploadImageButton)
        submitButton = findViewById(R.id.submitReviewButton)
        deleteImageButton = findViewById(R.id.deleteImageButton)

        // Load data from intent
        isEdit = intent.getBooleanExtra("isEdit", false)
        editingBook = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("bookMeta", BookMeta::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getSerializableExtra("bookMeta") as? BookMeta
        }

        if (isEdit && editingBook != null) {
            val book = editingBook!!
            titleEditText.setText(book.title)
            authorEditText.setText(book.author)
            reviewEditText.setText(book.review)
            ratingBar.rating = book.rating

            if (!book.imageUrl.isNullOrEmpty()) {
                Glide.with(this).load(book.imageUrl).into(bookImageView)
                deleteImageButton.visibility = View.VISIBLE
            } else {
                deleteImageButton.visibility = View.GONE
            }

            submitButton.text = "Update Review"
        } else {
            titleEditText.setText(intent.getStringExtra("title") ?: "")
            authorEditText.setText(intent.getStringExtra("author") ?: "")
            Glide.with(this).load(intent.getStringExtra("thumbnail")).into(bookImageView)
            deleteImageButton.visibility = View.GONE
        }

        bookImageView.setOnClickListener {
            val imageUrl = selectedImageUri?.toString() ?: editingBook?.imageUrl
            imageUrl?.let {
                val intent = Intent(this, FullImageActivity::class.java)
                intent.putExtra("imageUrl", it)
                startActivity(intent)
            }
        }
        uploadButton.setOnClickListener {
            showImagePickerDialog()
        }

        submitButton.setOnClickListener {
            uploadReview()
        }

        deleteImageButton.setOnClickListener {
            val imageUUID = editingBook?.imageUUID ?: ""
            val imageUrl = editingBook?.imageUrl ?: ""
            if (isEdit && (imageUUID.isNotEmpty() || imageUrl.isNotEmpty())) {
                deleteImageButton.visibility = View.GONE
                if (imageUUID.isNotEmpty()) {
                    bookStorage.deleteImage(userId, imageUUID)
                }
                editingBook?.imageUUID = ""
                editingBook?.imageUrl = ""
                Glide.with(this).clear(bookImageView)
                bookImageView.visibility = View.GONE
                Toast.makeText(this, "Image deleted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "No image to delete", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun uploadReview() {
        val title = titleEditText.text.toString()
        val author = authorEditText.text.toString()
        val review = reviewEditText.text.toString()
        val rating = ratingBar.rating
        val genre = intent.getStringExtra("genre") ?: "Other"


        if (title.isEmpty() || review.isEmpty()) {
            Toast.makeText(this, "Please complete title and review.", Toast.LENGTH_SHORT).show()
            return
        }

        val uploadAndSave = { uuid: String, imageUrl: String ->
            val book = BookMeta(
                firestoreID = editingBook?.firestoreID ?: "",
                title = title,
                author = author,
                review = review,
                rating = rating,
                imageUUID = uuid,
                imageUrl = imageUrl,
                userId = userId,
                timestamp = System.currentTimeMillis(),
                genre = genre
            )

            if (isEdit && editingBook != null) {
                dbHelper.updateBookMeta(book) {
                    Toast.makeText(this, "Review updated!", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } else {
                dbHelper.createBookMeta(book) {
                    Toast.makeText(this, "Book logged!", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }

        if (selectedImageUri != null) {
            if (isEdit && !editingBook?.imageUUID.isNullOrEmpty()) {
                bookStorage.deleteImage(userId, editingBook!!.imageUUID)
            }

            bookStorage.uploadImage(
                selectedImageUri!!,
                userId,
                onSuccess = { uuid, url -> uploadAndSave(uuid, url) },
                onFailure = {
                    Toast.makeText(this, "Image upload failed: ${it.message}", Toast.LENGTH_SHORT)
                        .show()
                })
        } else {
            uploadAndSave(editingBook?.imageUUID ?: "", editingBook?.imageUrl ?: "")
        }
    }
}