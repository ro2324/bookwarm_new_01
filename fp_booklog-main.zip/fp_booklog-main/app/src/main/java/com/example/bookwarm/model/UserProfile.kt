package com.example.bookwarm.model

data class UserProfile(
    val userId: String = "",
    val name: String = "",
    val profilePicUrl: String? = null
)