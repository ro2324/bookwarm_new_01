package com.example.bookwarm.model

data class Book(
    val title: String,
    val authors: String,
    val thumbnail: String,
    val genre: String = "Other"
)

