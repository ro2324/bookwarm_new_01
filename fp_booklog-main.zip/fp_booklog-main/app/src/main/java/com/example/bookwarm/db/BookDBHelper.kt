package com.example.bookwarm.db

import android.util.Log
import com.example.bookwarm.model.BookMeta
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class BookDBHelper {
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
    private val rootCollection = "logged_books"

    private fun limitAndGet(query: Query, resultListener: (List<BookMeta>) -> Unit) {
        query.limit(100)
            .get()
            .addOnSuccessListener { result ->
                resultListener(result.documents.mapNotNull {
                    it.toObject(BookMeta::class.java)
                })
            }
            .addOnFailureListener {
                Log.d(javaClass.simpleName, "Firestore fetch FAILED", it)
                resultListener(listOf())
            }
    }

    fun fetchUserBooks(userId: String, resultListener: (List<BookMeta>) -> Unit) {
        val query = db.collection(rootCollection)
            .whereEqualTo("userId", userId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
        limitAndGet(query, resultListener)
    }

    fun createBookMeta(bookMeta: BookMeta, resultListener: (Boolean) -> Unit) {
        val docRef = db.collection(rootCollection).document()
        val bookWithId = bookMeta.copy(firestoreID = docRef.id)
        docRef.set(bookWithId)
            .addOnSuccessListener { resultListener(true) }
            .addOnFailureListener { resultListener(false) }
    }


    fun deleteBook(bookMeta: BookMeta, resultListener: (Boolean) -> Unit) {
        db.collection(rootCollection)
            .document(bookMeta.firestoreID)
            .delete()
            .addOnSuccessListener { resultListener(true) }
            .addOnFailureListener { resultListener(false) }
    }

    fun updateBookMeta(bookMeta: BookMeta, resultListener: (Boolean) -> Unit) {
        if (bookMeta.firestoreID.isBlank()) {
            resultListener(false)
            return
        }

        db.collection(rootCollection)
            .document(bookMeta.firestoreID)
            .set(bookMeta)
            .addOnSuccessListener { resultListener(true) }
            .addOnFailureListener { resultListener(false) }
    }

}
