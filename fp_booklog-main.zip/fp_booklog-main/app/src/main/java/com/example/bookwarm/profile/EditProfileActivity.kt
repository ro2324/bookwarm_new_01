package com.example.bookwarm.profile

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bookwarm.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

class EditProfileActivity : AppCompatActivity() {

    private lateinit var editDisplayName: EditText
    private lateinit var editBio: EditText
    private lateinit var saveButton: Button

    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        editDisplayName = findViewById(R.id.editDisplayName)
        editBio = findViewById(R.id.editBio)
        saveButton = findViewById(R.id.saveButton)
        loadProfileData()
        saveButton.setOnClickListener {
            saveProfileData()
        }
    }

    private fun loadProfileData() {
        val userId = auth.currentUser?.uid ?: return
        firestore.collection("users").document(userId).get().addOnSuccessListener { document ->
                if (document.exists()) {
                    editDisplayName.setText(document.getString("displayName") ?: "")
                    editBio.setText(document.getString("bio") ?: "")
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Failed to load profile", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveProfileData() {
        val userId = auth.currentUser?.uid ?: return
        val updatedName = editDisplayName.text?.toString()?.trim() ?: ""
        val updatedBio = editBio.text?.toString()?.trim() ?: ""

        val updates = mapOf(
            "displayName" to updatedName, "bio" to updatedBio
        )

        firestore.collection("users").document(userId).set(updates, SetOptions.merge())
            .addOnSuccessListener {
                Toast.makeText(this, "Profile updated", Toast.LENGTH_SHORT).show()
                finish()
            }.addOnFailureListener { e ->
                Log.e("EditProfileActivity", "Error updating profile", e)
                Toast.makeText(this, "Update failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
