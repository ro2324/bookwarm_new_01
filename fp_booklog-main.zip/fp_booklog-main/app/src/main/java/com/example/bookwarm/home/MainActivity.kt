package com.example.bookwarm.home

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.bookwarm.R
import com.example.bookwarm.booksearch.BookSearchActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bookSearchButton = findViewById<Button>(R.id.bookSearchButton)
        bookSearchButton.setOnClickListener {
            startActivity(Intent(this, BookSearchActivity::class.java))
        }

    }
}
