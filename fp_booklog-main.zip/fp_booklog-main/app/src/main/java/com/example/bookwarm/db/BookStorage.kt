package com.example.bookwarm.db

import android.net.Uri
import android.util.Log
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.StorageReference
import java.util.UUID

class BookStorage {
    private val storageRef: StorageReference =
        FirebaseStorage.getInstance().reference.child("images")

    fun uploadImage(
        uri: Uri,
        userId: String,
        onSuccess: (uuid: String, downloadUrl: String) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val uuid = UUID.randomUUID().toString()
        val imageRef = storageRef.child("$userId/$uuid.jpg")

        val metadata = StorageMetadata.Builder()
            .setContentType("image/jpeg")
            .build()

        imageRef.putFile(uri, metadata)
            .continueWithTask { task ->
                if (!task.isSuccessful) throw task.exception!!
                imageRef.downloadUrl
            }
            .addOnSuccessListener { downloadUrl ->
                onSuccess(uuid, downloadUrl.toString())
            }
            .addOnFailureListener { exception ->
                Log.e("BookStorage", "Upload failed", exception)
                onFailure(exception)
            }
    }

    fun deleteImage(userId: String, imageUUID: String) {
        val fileRef = storageRef.child("$userId/$imageUUID.jpg")
        fileRef.delete()
            .addOnSuccessListener {
                Log.d("BookStorage", "Image deleted: $imageUUID")
            }
            .addOnFailureListener {
                Log.e("BookStorage", "Image deletion failed: ${it.message}")
            }
    }
}
