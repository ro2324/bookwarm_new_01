package com.example.bookwarm.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class MyReviewViewModel : ViewModel() {
    private val _userBooks = MutableLiveData<List<BookMeta>>()
    val userBooks: LiveData<List<BookMeta>> get() = _userBooks

    fun fetchUserBooks(userId: String) {
        FirebaseFirestore.getInstance()
            .collection("logged_books")
            .whereEqualTo("userId", userId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { snapshot ->
                val books = snapshot.documents.mapNotNull { it.toObject(BookMeta::class.java) }
                _userBooks.postValue(books)
            }
            .addOnFailureListener {
                _userBooks.postValue(emptyList())
            }
    }

}
