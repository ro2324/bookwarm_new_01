package com.example.bookwarm.ui.stats

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap

class ReadingStatsViewModel : ViewModel() {

    private val _totalBooks = MutableLiveData<Int>()
    val totalBooks: LiveData<Int> get() = _totalBooks

    private val _averageRating = MutableLiveData<Float>()
    val averageRating: LiveData<Float> get() = _averageRating

    private val _monthlyReadingData = MutableLiveData<Map<String, Int>>()
    val monthlyReadingData: LiveData<Map<String, Int>> get() = _monthlyReadingData

    private val _genreDistribution = MutableLiveData<Map<String, Float>>()
    val genreDistribution: LiveData<Map<String, Float>> get() = _genreDistribution

    private val db = FirebaseFirestore.getInstance()

    fun loadUserStats(userId: String) {
        db.collection("logged_books")
            .whereEqualTo("userId", userId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { result ->
                val total = result.size()
                val ratingSum = result.sumOf { it.getDouble("rating") ?: 0.0 }

                val monthlyMap = HashMap<String, Int>()
                val genreMap = HashMap<String, Int>()

                val dateFormat = SimpleDateFormat("MMM", Locale.getDefault())

                for (doc in result) {
                    val timestamp = doc.getLong("timestamp") ?: continue
                    val rawGenre = doc.getString("genre") ?: "Other"
                    val genre = genericGenre(rawGenre)

                    val month = dateFormat.format(Date(timestamp))
                    monthlyMap[month] = (monthlyMap[month] ?: 0) + 1
                    genreMap[genre] = (genreMap[genre] ?: 0) + 1
                }

                _totalBooks.value = total
                _averageRating.value = if (total > 0) (ratingSum / total).toFloat() else 0f
                _monthlyReadingData.value = monthlyMap.toSortedMap(compareBy {
                    try {
                        SimpleDateFormat("MMM", Locale.ENGLISH).parse(it)?.month ?: 0
                    } catch (e: Exception) {
                        0
                    }
                })
                _genreDistribution.value = genreMap.mapValues {
                    (it.value.toFloat() / total) * 100f
                }
            }
            .addOnFailureListener {
                _totalBooks.value = 0
                _averageRating.value = 0f
                _monthlyReadingData.value = emptyMap()
                _genreDistribution.value = emptyMap()
            }
    }

    private fun genericGenre(rawGenre: String): String {
        val genreLowerCase = rawGenre.lowercase()
        Log.d("Reading stats ViewModel","Genre: $genreLowerCase")
        return when {
            "fiction" in genreLowerCase && ("science" in genreLowerCase || "fantasy" in genreLowerCase) -> "Sci-Fi & Fantasy"
            "mystery" in genreLowerCase || "thriller" in genreLowerCase || "suspense" in genreLowerCase || "detective" in genreLowerCase -> "Mystery & Thriller"
            "non-fiction" in genreLowerCase || "nonfiction" in genreLowerCase -> "Non-Fiction"
            "romance" in genreLowerCase -> "Romance"
            "comics" in genreLowerCase || "graphic" in genreLowerCase -> "Comics"
            else -> "Other"
        }
    }

}
