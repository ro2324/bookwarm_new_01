package com.example.bookwarm.activity

import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.bookwarm.R

class FullImageActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_image)

        val imageView = findViewById<ImageView>(R.id.fullImageView)
        val imageUrl = intent.getStringExtra("imageUrl")
        if (!imageUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .into(findViewById(R.id.fullImageView))
        } else {
            imageView.setImageResource(R.drawable.ic_cloud_download_black_24dp) // fallback
        }

        imageView.setOnClickListener {
            finish()
        }
    }
}
