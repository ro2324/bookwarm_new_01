package com.example.bookwarm.adapter

import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.bookwarm.databinding.ItemSuggestionBinding
import com.example.bookwarm.model.UserProfile

class SuggestionsAdapter(
    private val onFollowClick: (userId: String) -> Unit
) : RecyclerView.Adapter<SuggestionsAdapter.SuggestionViewHolder>() {

    private val suggestions = mutableListOf<UserProfile>()

    @SuppressLint("NotifyDataSetChanged")
    fun submitList(list: List<UserProfile>) {
        Log.d("SuggestionsAdapter", "Submitting ${list.size} suggestions")
        suggestions.clear()
        suggestions.addAll(list)
        notifyDataSetChanged()
    }

    inner class SuggestionViewHolder(private val binding: ItemSuggestionBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(user: UserProfile) {
            binding.userName.text = user.name

            if (!user.profilePicUrl.isNullOrBlank()) {
                Glide.with(binding.root.context)
                    .load(user.profilePicUrl)
                    .circleCrop()
                    .into(binding.userProfilePic)
            }
            binding.followButton.setOnClickListener {
                onFollowClick(user.userId)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SuggestionViewHolder {
        val binding = ItemSuggestionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return SuggestionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SuggestionViewHolder, position: Int) {
        holder.bind(suggestions[position])
    }

    override fun getItemCount(): Int = suggestions.size

}
