package com.example.bookwarm.feed

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.bookwarm.R

class FeedActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feed)
    }
}
