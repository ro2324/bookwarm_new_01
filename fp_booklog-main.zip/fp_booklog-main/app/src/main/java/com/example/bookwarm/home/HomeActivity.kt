package com.example.bookwarm.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.bookwarm.R
import com.example.bookwarm.review.MyReviewActivity
import com.example.bookwarm.booksearch.BookSearchActivity
import com.example.bookwarm.feed.FeedActivity
import com.example.bookwarm.profile.ProfileActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigationView)

        // Set default selected item
        bottomNav.selectedItemId = R.id.nav_home

        // Handle navigation item clicks
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    true
                }

                R.id.nav_reviews -> {
                    startActivity(Intent(this, MyReviewActivity::class.java))
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }

                R.id.nav_feed -> {
                    startActivity(Intent(this, FeedActivity::class.java))
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, BookSearchActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
}